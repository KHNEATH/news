<?php
include('../include/dbconn.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Delete post
    $delete_id = intval($_POST['delete_id']);
    $sql = "DELETE FROM post WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    // Close connection
    $stmt->close();
    $conn->close();

    // Redirect to the same page to refresh the list
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}


// Initialize variables
$newsId = 1; // Assuming this is the ID of the news item to display

// Check if session variable is not set (indicating first visit in this session)
if (!isset($_SESSION['visited'])) {
    try {
        // Increment view count in database
        $incrementViewCountStmt = $dbh->prepare("UPDATE viewer SET view_count = view_count + 1 WHERE id = :id");
        $incrementViewCountStmt->bindParam(':id', $newsId, PDO::PARAM_INT);
        $incrementViewCountStmt->execute();

        // Set session variable to indicate visit
        $_SESSION['visited'] = true;
    } catch (PDOException $e) {
        die('Database error: ' . $e->getMessage());
    }
}

// Fetch the news item to display
try {
    $stmt = $dbh->prepare("SELECT * FROM viewer WHERE id = :id");
    $stmt->bindParam(':id', $newsId, PDO::PARAM_INT);
    $stmt->execute();
    $newsItem = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$newsItem) {
        echo 'News item not found.';
        exit();
    }
} catch (PDOException $e) {
    die('Database error: ' . $e->getMessage());
}

if (isset($_SESSION['userid']) && !empty($_SESSION['userid'])) {
    if ($_SESSION['role'] === 'admin') {
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
            if (isset($_FILES["profile"]) && is_array($_FILES["profile"]["error"]) && count($_FILES["profile"]["error"]) > 0) {
                $uploadDir = "../uploads/";
                $uploadedFiles = [];
                $uploadErrors = [];

                foreach ($_FILES["profile"]["error"] as $key => $error) {
                    if ($error == 0) {
                        $uploadFile = $uploadDir . basename($_FILES["profile"]["name"][$key]);

                        if (move_uploaded_file($_FILES["profile"]["tmp_name"][$key], $uploadFile)) {
                            $uploadedFiles[] = basename($_FILES["profile"]["name"][$key]);
                        } else {
                            $uploadErrors[] = "Error uploading " . $_FILES["profile"]["name"][$key];
                        }
                    } else {
                        $uploadErrors[] = "Error uploading " . $_FILES["profile"]["name"][$key];
                    }
                }

                if (empty($uploadErrors)) {
                    $title = $_POST['title'];
                    $text = $_POST['text'];
                    $adminId = $_SESSION['userid'];
                    date_default_timezone_set('Asia/Bangkok');
                    $date = date('Y-m-d H:i:s');
                    $profiles = implode(",", $uploadedFiles);

                    $sql = "INSERT INTO post (profile, title, text, admin_id, created_at) 
                            VALUES (:profile, :title, :text, :admin_id, :date)";
                    $stmt = $dbh->prepare($sql);

                    $stmt->bindParam(':profile', $profiles);
                    $stmt->bindParam(':title', $title);
                    $stmt->bindParam(':text', $text);
                    $stmt->bindParam(':admin_id', $adminId);
                    $stmt->bindParam(':date', $date);

                    if ($stmt->execute()) {
                        $msg = "File uploaded successfully ^-^.";
                        header("Location: admin.php");
                        exit();
                    } else {
                        $error = "Error: " . $dbh->errorInfo();
                    }
                } else {
                    $error = implode("<br>", $uploadErrors);
                }
            } else {
                $error = "No file uploaded or an error occurred during upload.";
            }
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit'])) {
            $conn = new mysqli($servername, $username, $password, $dbname);
            $edit_id = intval($_POST['edit_id']);
            $edit_title = $conn->real_escape_string($_POST['title']);
            $edit_text = $conn->real_escape_string($_POST['text']);
            $sql = "UPDATE post SET title = ?, text = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $edit_title, $edit_text, $edit_id);

            if ($stmt->execute()) {
                echo "Record updated successfully";
            } else {
                echo "Error updating record: " . $conn->error;
            }

            $stmt->close();
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
    } else {
        echo "You do not have permission to access this page.";
    }
} else {
    header('location: ../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<?php
$title = 'Admin Post';
include('../include/header.php')
?>

<body>
    <?php
    include('../include/navbar.php')
    ?>
    <div class="container">
        <div class="card rounded shadow-none mt-3 mb-2">
            <div class="card-body">
                <div class="card-header text-center mb-3 bg-none">
                    <div class="row d-flex align-items-center ">
                        <div class="col-4"></div>
                        <div class="col-4">
                            <h2 mb-0>Admin Post Form</h2>
                        </div>
                        <div class="col-4 text-end">
                            <button type="button mt-3" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                Post News
                            </button>
                        </div>
                    </div>
                    <!-- Modal Post -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Post</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form method="post" action="" enctype="multipart/form-data">
                                    <div class="modal-body">
                                        <input type="hidden" name="edit_id" value="<?php echo htmlentities($postData['id']); ?>">
                                        <div class="flex-shrink-0 mt-n5 mx-sm-0 mx-auto">
                                            <!-- Clickable profile picture to change profile image -->
                                            <label for="profileInput" class="profile-image">
                                                <?php
                                                if (!empty($postData['profile'])) {
                                                    $profileImages = explode(",", $postData['profile']);
                                                ?>
                                                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                                        <div class="carousel-inner">
                                                            <?php
                                                            foreach ($profileImages as $index => $image) {
                                                                $active = ($index === 0) ? 'active' : '';
                                                                echo '<div class="carousel-item ' . $active . '">';
                                                                echo '<img style="object-fit: cover; width:100%; height: auto;" src="../uploads/' . trim($image) . '" />';
                                                                echo '</div>';
                                                            }
                                                            ?>
                                                        </div>
                                                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                            <span class="visually-hidden">Previous</span>
                                                        </button>
                                                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                            <span class="visually-hidden">Next</span>
                                                        </button>
                                                    </div>
                                                <?php } else { ?>
                                                    <!-- Placeholder image if no profile picture exists -->
                                                    <img src="placeholder.jpg" alt="user image" class="d-block h-auto ms-0 ms-sm-5 rounded border p-1 bg-light user-profile-img shadow-sm" height="150px" width="150px" style="object-fit: cover;">
                                                <?php } ?>
                                            </label>
                                            <input type="file" name="profile[]" id="profileInput" class="d-none" accept="image/*" multiple>
                                        </div>
                                        <div class="form-group">
                                            <label for="title">Title:</label>
                                            <input type="text" class="form-control" id="title" name="title" value="<?php echo isset($postData['title']) ? htmlspecialchars($postData['title']) : ''; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="text">Text:</label>
                                            <textarea class="form-control" id="text" name="text" rows="5" required><?php echo isset($postData['text']) ? htmlspecialchars($postData['text']) : ''; ?></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" name="edit" class="btn btn-primary">Submit</button>
                                    </div>
                                </form>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <h2>Manage Posts</h2>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col" class="col-2">Title</th>
                            <th scope="col" class="col-8">Text</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Database connection
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "newssystem2";

                        // Create connection
                        $conn = new mysqli($servername, $username, $password, $dbname);

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Fetch posts
                        $sql = "SELECT id, title, text FROM post";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            // Output data of each row
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                            <th scope='row'>" . htmlspecialchars($row['id']) . "</th>
                                            <td>" . htmlspecialchars($row['title']) . "</td>
                                            <td class='text-truncate' style='max-width: 300px;'>" . htmlspecialchars($row['text']) . "</td>
                                            <td class='action-buttons'>
                                                <a class='btn btn-sm btn-primary' href='edit-post.php?eid=" . htmlspecialchars($row['id']) . "'>Edit</a>
                                                <form method='post' action='' style='display:inline;'>
                                                    <input type='hidden' name='delete_id' value='" . htmlspecialchars($row['id']) . "'>
                                                    <button type='button' class='btn btn-sm btn-danger' data-bs-toggle='modal' data-bs-target='#modalCenter' onclick='setDeleteId(" . htmlspecialchars($row['id']) . ")'>Delete</button>
                                                </form>
                                            </td>
                                        </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='4'>No posts found</td></tr>";
                        }

                        // Close connection
                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- model Detele -->
            <div class="modal fade" id="modalCenter" tabindex="-1" style="display: none;" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title " id="modalCenterTitle">Confirm Delete</h3>

                        </div>
                        <div class="modal-body">
                            <h5>Are you want to delete?</h5>
                        </div>
                        <div class="modal-footer">
                            <form method="post" action="">
                                <input type="hidden" name="delete_id" id="delete_id">
                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">No</button>
                                <button type="submit" name="delete" class="btn btn-danger">Yes</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <?php
    include('../include/footer.php')
    ?>
</body>

<script>
    function populateEditModal(id, title, text) {
        document.getElementById('edit_id').value = id;
        document.getElementById('title').value = title;
        document.getElementById('text').value = text;
    }

    function setDeleteId(id) {
        document.getElementById('delete_id').value = id;
    }
</script>
<!-- Include Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</html>